(function () {
    "use strict";

    const PAGE_SIZE_DEFAULT = 10;
    const SUPABASE_FETCH_LIMIT = 1000;
    const DAET_BARANGAYS = [
        "Alawihao",
        "Awitan",
        "Bagasbas",
        "Barangay I",
        "Barangay II",
        "Barangay III",
        "Barangay IV",
        "Barangay V",
        "Barangay VI",
        "Barangay VII",
        "Barangay VIII",
        "Bibirao",
        "Borabod",
        "Calasgasan",
        "Camambugan",
        "Cobangbang",
        "Dogongan",
        "Gahonon",
        "Gubat",
        "Lag-on",
        "Magang",
        "Mambalite",
        "Mancruz",
        "Pamorangon",
        "San Isidro"
    ];
    const DAET_BARANGAY_ALIASES = {
        "Barangay I": ["BRGY I", "BRGY 1", "BARANGAY 1"],
        "Barangay II": ["BRGY II", "BRGY 2", "BARANGAY 2"],
        "Barangay III": ["BRGY III", "BRGY 3", "BARANGAY 3"],
        "Barangay IV": ["BRGY IV", "BRGY 4", "BARANGAY 4"],
        "Barangay V": ["BRGY V", "BRGY 5", "BARANGAY 5"],
        "Barangay VI": ["BRGY VI", "BRGY 6", "BARANGAY 6"],
        "Barangay VII": ["BRGY VII", "BRGY 7", "BARANGAY 7"],
        "Barangay VIII": ["BRGY VIII", "BRGY 8", "BARANGAY 8"]
    };

    let allRows = [];
    let filteredRows = [];
    let currentPage = 1;
    let pageSize = PAGE_SIZE_DEFAULT;
    let barangayLookup = null;

    function byId(id) {
        return document.getElementById(id);
    }

    function escapeHtml(value) {
        return (value || "")
            .toString()
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function cleanupLookupKey(value) {
        return (value || "")
            .toString()
            .trim()
            .replace(/\s+/g, " ")
            .toLowerCase();
    }

    function cleanupBarangayKey(value) {
        return cleanupLookupKey((value || "")
            .toString()
            .replace(/,\s*daet$/i, ""));
    }

    function getBarangayLookup() {
        if (barangayLookup) {
            return barangayLookup;
        }

        barangayLookup = {};
        DAET_BARANGAYS.forEach(function (barangay) {
            const variants = [barangay].concat(DAET_BARANGAY_ALIASES[barangay] || []);
            if (!/^barangay\s+/i.test(barangay)) {
                variants.push("Barangay " + barangay);
            }
            variants.forEach(function (variant) {
                barangayLookup[cleanupBarangayKey(variant)] = barangay;
                barangayLookup[cleanupBarangayKey(variant + ", Daet")] = barangay;
            });
        });

        return barangayLookup;
    }

    function normalizeBarangay(value) {
        const key = cleanupBarangayKey(value);
        if (!key) {
            return "";
        }
        return getBarangayLookup()[key] || (value || "").toString().trim();
    }

    function buildApplicantName(profile) {
        const first = (profile && profile.first_name ? profile.first_name : "").trim();
        const middle = (profile && profile.middle_name ? profile.middle_name : "").trim();
        const last = (profile && profile.last_name ? profile.last_name : "").trim();
        const joined = [first, middle, last].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
        if (joined) {
            return joined;
        }
        return profile && profile.email ? profile.email : "Unknown Applicant";
    }

    function formatDate(value) {
        if (!value) {
            return "-";
        }
        const parsed = new Date(value);
        if (Number.isNaN(parsed.getTime())) {
            return value;
        }
        return parsed.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    }

    function showStatus(message, type) {
        const box = byId("secretaryNoFormStatus");
        if (!box) {
            return;
        }
        if (!message) {
            box.className = "alert d-none";
            box.textContent = "";
            return;
        }
        box.className = "alert " + (type || "alert-info");
        box.textContent = message;
    }

    function pageCount(totalRows) {
        if (totalRows <= 0) {
            return 1;
        }
        return Math.ceil(totalRows / pageSize);
    }

    function pageItemMarkup(label, targetPage, disabled, active, ariaLabel) {
        const itemClass = "page-item" + (disabled ? " disabled" : "") + (active ? " active" : "");
        return (
            '<li class="' + itemClass + '">' +
            '<button class="page-link" type="button" data-page="' + targetPage + '" aria-label="' + escapeHtml(ariaLabel || label) + '">' +
            escapeHtml(label) +
            "</button>" +
            "</li>"
        );
    }

    function renderMetrics(rows) {
        const draftOnly = rows.filter(function (row) { return row.form_state === "Draft Only"; }).length;
        const noApplication = rows.filter(function (row) { return row.form_state === "No Application Yet"; }).length;

        if (byId("secretaryNoFormTotal")) {
            byId("secretaryNoFormTotal").textContent = String(rows.length);
        }
        if (byId("secretaryNoFormDraftOnly")) {
            byId("secretaryNoFormDraftOnly").textContent = String(draftOnly);
        }
        if (byId("secretaryNoFormNoApplication")) {
            byId("secretaryNoFormNoApplication").textContent = String(noApplication);
        }
    }

    function renderTable(rows) {
        const tbody = byId("secretaryNoFormTableBody");
        if (!tbody) {
            return;
        }
        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No users matched the current filters.</td></tr>';
            return;
        }

        tbody.innerHTML = rows.map(function (row) {
            return (
                "<tr>" +
                "<td>" + escapeHtml(row.applicant_name) + "</td>" +
                "<td>" + escapeHtml(row.barangay || "No Barangay") + "</td>" +
                "<td>" + escapeHtml(row.email || "-") + "</td>" +
                "<td>" + escapeHtml(row.form_state) + "</td>" +
                "<td>" + escapeHtml(formatDate(row.created_at)) + "</td>" +
                "</tr>"
            );
        }).join("");
    }

    function renderPaginationInfo(totalRows) {
        const info = byId("secretaryNoFormPaginationInfo");
        if (!info) {
            return;
        }
        if (totalRows <= 0) {
            info.textContent = "Showing 0 of 0 records";
            return;
        }
        const start = (currentPage - 1) * pageSize + 1;
        const end = Math.min(currentPage * pageSize, totalRows);
        info.textContent = "Showing " + start + "-" + end + " of " + totalRows + " records";
    }

    function renderPagination(totalRows) {
        const pagination = byId("secretaryNoFormPagination");
        if (!pagination) {
            return;
        }
        if (totalRows <= 0) {
            pagination.innerHTML = "";
            return;
        }

        const totalPages = pageCount(totalRows);
        const items = [];
        items.push(pageItemMarkup("Previous", currentPage - 1, currentPage <= 1, false, "Previous page"));

        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + 4);
        if (endPage - startPage < 4) {
            startPage = Math.max(1, endPage - 4);
        }

        for (let page = startPage; page <= endPage; page += 1) {
            items.push(pageItemMarkup(String(page), page, false, page === currentPage, "Page " + page));
        }

        items.push(pageItemMarkup("Next", currentPage + 1, currentPage >= totalPages, false, "Next page"));
        pagination.innerHTML = items.join("");
    }

    function applyFilters(resetPage) {
        const searchValue = ((byId("secretaryNoFormSearchInput") || {}).value || "").toString().trim().toLowerCase();
        const barangayValue = ((byId("secretaryNoFormBarangayFilter") || {}).value || "all").toString();
        const typeValue = ((byId("secretaryNoFormTypeFilter") || {}).value || "all").toString();

        filteredRows = allRows.filter(function (row) {
            const matchesSearch = !searchValue || row.applicant_name.toLowerCase().indexOf(searchValue) !== -1;
            const matchesBarangay = barangayValue === "all" || (row.barangay || "No Barangay") === barangayValue;
            const matchesType =
                typeValue === "all" ||
                (typeValue === "draft_only" && row.form_state === "Draft Only") ||
                (typeValue === "no_application" && row.form_state === "No Application Yet");
            return matchesSearch && matchesBarangay && matchesType;
        });

        renderMetrics(filteredRows);

        if (resetPage) {
            currentPage = 1;
        }

        const totalPages = pageCount(filteredRows.length);
        if (currentPage > totalPages) {
            currentPage = totalPages;
        }
        if (currentPage < 1) {
            currentPage = 1;
        }

        const start = (currentPage - 1) * pageSize;
        const pageRows = filteredRows.slice(start, start + pageSize);

        renderTable(pageRows);
        renderPaginationInfo(filteredRows.length);
        renderPagination(filteredRows.length);
    }

    function populateBarangayFilter(rows) {
        const select = byId("secretaryNoFormBarangayFilter");
        if (!select) {
            return;
        }
        const currentValue = select.value || "all";
        const options = Array.from(new Set(rows.map(function (row) {
            return row.barangay || "No Barangay";
        }))).sort(function (left, right) {
            if (left === "No Barangay") {
                return 1;
            }
            if (right === "No Barangay") {
                return -1;
            }
            return left.localeCompare(right);
        });

        select.innerHTML = '<option value="all">All</option>' + options.map(function (barangay) {
            return '<option value="' + escapeHtml(barangay) + '">' + escapeHtml(barangay) + "</option>";
        }).join("");

        if (options.indexOf(currentValue) !== -1 || currentValue === "all") {
            select.value = currentValue;
        }
    }

    function bindEvents() {
        const applyBtn = byId("secretaryNoFormApplyFilterBtn");
        if (applyBtn) {
            applyBtn.addEventListener("click", function () {
                applyFilters(true);
            });
        }

        const pageSizeSelect = byId("secretaryNoFormPageSize");
        if (pageSizeSelect) {
            pageSizeSelect.addEventListener("change", function () {
                pageSize = Math.max(1, Number(pageSizeSelect.value || PAGE_SIZE_DEFAULT));
                applyFilters(true);
            });
        }

        const pagination = byId("secretaryNoFormPagination");
        if (pagination) {
            pagination.addEventListener("click", function (event) {
                const button = event.target.closest("button[data-page]");
                if (!button || button.closest(".disabled")) {
                    return;
                }
                const nextPage = Number(button.getAttribute("data-page"));
                const totalPages = pageCount(filteredRows.length);
                if (Number.isNaN(nextPage) || nextPage < 1 || nextPage > totalPages) {
                    return;
                }
                currentPage = nextPage;
                applyFilters(false);
            });
        }
    }

    async function fetchAllApplicantProfiles(context) {
        const rows = [];

        for (let from = 0; ; from += SUPABASE_FETCH_LIMIT) {
            const result = await context.client
                .from("profiles")
                .select("id, first_name, middle_name, last_name, email, barangay, created_at")
                .eq("role", "applicant")
                .order("created_at", { ascending: false })
                .range(from, from + SUPABASE_FETCH_LIMIT - 1);

            if (result.error) {
                return {
                    data: rows,
                    error: result.error
                };
            }

            const batch = result.data || [];
            rows.push.apply(rows, batch);
            if (batch.length < SUPABASE_FETCH_LIMIT) {
                break;
            }
        }

        return {
            data: rows,
            error: null
        };
    }

    async function fetchAllApplications(context) {
        const rows = [];

        for (let from = 0; ; from += SUPABASE_FETCH_LIMIT) {
            const result = await context.client
                .from("applications")
                .select("applicant_id, status, updated_at, created_at")
                .order("updated_at", { ascending: false })
                .range(from, from + SUPABASE_FETCH_LIMIT - 1);

            if (result.error) {
                return {
                    data: rows,
                    error: result.error
                };
            }

            const batch = result.data || [];
            rows.push.apply(rows, batch);
            if (batch.length < SUPABASE_FETCH_LIMIT) {
                break;
            }
        }

        return {
            data: rows,
            error: null
        };
    }

    async function loadData(context) {
        showStatus("");
        renderTable([]);

        const [profilesResult, applicationsResult] = await Promise.all([
            fetchAllApplicantProfiles(context),
            fetchAllApplications(context)
        ]);

        if (profilesResult.error) {
            showStatus("Failed to load registered applicant accounts: " + profilesResult.error.message, "alert-danger");
            return;
        }

        if (applicationsResult.error) {
            showStatus("Failed to compare application records: " + applicationsResult.error.message, "alert-danger");
            return;
        }

        const profileRows = profilesResult.data || [];
        const applicationRows = applicationsResult.data || [];
        const applicationMap = {};

        applicationRows.forEach(function (application) {
            if (!application || !application.applicant_id) {
                return;
            }
            if (!applicationMap[application.applicant_id]) {
                applicationMap[application.applicant_id] = [];
            }
            applicationMap[application.applicant_id].push(application);
        });

        allRows = profileRows.map(function (profile) {
            const applications = applicationMap[profile.id] || [];
            const hasSubmittedForm = applications.some(function (application) {
                return (application.status || "").toString().trim().toLowerCase() !== "draft";
            });
            if (hasSubmittedForm) {
                return null;
            }

            const hasDraftOnly = applications.some(function (application) {
                return (application.status || "").toString().trim().toLowerCase() === "draft";
            });

            return {
                id: profile.id,
                applicant_name: buildApplicantName(profile),
                barangay: normalizeBarangay(profile.barangay || "") || "No Barangay",
                email: profile.email || "",
                created_at: profile.created_at || "",
                form_state: hasDraftOnly ? "Draft Only" : "No Application Yet"
            };
        }).filter(Boolean);

        populateBarangayFilter(allRows);
        applyFilters(true);
    }

    async function init() {
        const context = await window.ldssAuthReadyPromise;
        if (!context || !context.client || !context.user) {
            return;
        }

        bindEvents();
        await loadData(context);
    }

    window.addEventListener("DOMContentLoaded", init);
})();
